from sqlalchemy.future import select
from sqlalchemy import insert
from sqlalchemy.orm import selectinload
from app.models import User, Transaction
from app.schemas import UserCreate, TransactionCreate
from app.database import async_session

async def get_user_by_uid(uid: str):
    async with async_session() as session:
        result = await session.execute(select(User).filter(User.firebase_uid == uid))
        return result.scalars().first()

async def create_user(user: UserCreate):
    async with async_session() as session:
        db_user = User(firebase_uid=user.firebase_uid, email=user.email)
        session.add(db_user)
        await session.commit()
        await session.refresh(db_user)
        return db_user

async def create_transaction(user_id: int, txn: TransactionCreate):
    async with async_session() as session:
        new_txn = Transaction(
            user_id=user_id,
            transaction_amount=txn.transaction_amount,
            kyc_verified=txn.kyc_verified,
            account_age_days=txn.account_age_days,
            channel=txn.channel,
            timestamp=txn.timestamp,
            fraud_probability=txn.fraud_probability,
            is_fraud=txn.is_fraud,
        )
        session.add(new_txn)
        await session.commit()
        await session.refresh(new_txn)
        return new_txn

async def get_transactions_for_user(user_id: int, limit: int = 50):
    async with async_session() as session:
        result = await session.execute(
            select(Transaction).filter(Transaction.user_id == user_id).order_by(Transaction.timestamp.desc()).limit(limit)
        )
        return result.scalars().all()
