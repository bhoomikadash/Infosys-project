# import torch
# import joblib
# from fastapi import FastAPI, Depends, HTTPException, status, File, UploadFile, Body, Header
# from fastapi.middleware.cors import CORSMiddleware
# from fastapi.responses import JSONResponse
# import logging
# from app.firebase import verify_token
# from app.database import connect_db, disconnect_db
# from app.schemas import UserCreate, TransactionCreate
# from app.crud import get_user_by_uid, create_user, create_transaction, get_transactions_for_user
# from app.services import preprocess_transaction, predict_fraud
# import io
# import pandas as pd
# from app.services import RegularizedHybridModel


# app = FastAPI()

# # Load ML model


# # Initialize model with correct parameters
# model = RegularizedHybridModel(feature_dim=15)  # use correct feature_dim matching training
# # Load weights
# state_dict = torch.load('models/4th_model.pth', map_location=torch.device('cpu'))
# model.load_state_dict(state_dict)
# # Set model to eval mode
# model.eval()


# # Load scaler and encoder
# scaler = joblib.load('models/scaler.joblib')
# encoder = joblib.load('models/encoder.joblib')

# # CORS Middleware for local testing - restrict in production!
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],  # <-- restrict this for production
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# # Logging setup
# logger = logging.getLogger("uvicorn.error")
# logger.setLevel(logging.INFO)

# @app.on_event("startup")
# async def startup():
#     await connect_db()

# @app.on_event("shutdown")
# async def shutdown():
#     await disconnect_db()

# # Dependency for Firebase Authentication
# async def get_current_user(authorization: str = Header(None)):
#     if not authorization or not authorization.startswith("Bearer "):
#         raise HTTPException(status_code=401, detail="Missing or invalid authorization token")
#     token = authorization.split(" ")[1]
#     user_info = await verify_token(token)
#     if not user_info:
#         raise HTTPException(status_code=401, detail="Invalid Firebase token")
#     user = await get_user_by_uid(user_info['uid'])
#     if not user:
#         user = await create_user(UserCreate(firebase_uid=user_info['uid'], email=user_info.get('email', '')))
#     return user

# # Auth route - get current user info
# @app.get("/auth/me")
# async def read_me(user=Depends(get_current_user)):
#     return {"user_id": user.id, "email": user.email}

# # CSV upload & analyze
# @app.post("/data/upload")
# async def upload_csv(file: UploadFile = File(...), user=Depends(get_current_user)):
#     contents = await file.read()
#     try:
#         df = pd.read_csv(io.BytesIO(contents))
#         # Add more detailed data analysis if needed here
#         return {"message": "CSV processed successfully", "row_count": len(df), "column_count": len(df.columns)}
#     except Exception as e:
#         logger.error(f"CSV processing error: {e}")
#         raise HTTPException(status_code=400, detail="Invalid CSV file")

# # Real-time fraud prediction endpoint
# @app.post("/predict")
# async def predict_transaction_route(body: dict = Body(...), user=Depends(get_current_user)):
#     try:
#         # Preprocess and predict using loaded model and scaler/encoder
#         tensor_input = preprocess_transaction(body)
#         prob, pred = predict_fraud(tensor_input)

#         # Save transaction data and prediction result
#         txn_record = TransactionCreate(
#             transaction_amount=body['transaction_amount'],
#             kyc_verified=body['kyc_verified'],
#             account_age_days=body['account_age_days'],
#             channel=body['channel'],
#             timestamp=pd.to_datetime(body['timestamp']),
#             fraud_probability=prob,
#             is_fraud=bool(pred)
#         )
#         await create_transaction(user.id, txn_record)

#         return {"fraud_probability": prob, "is_fraud": bool(pred)}
#     except Exception as e:
#         logger.error(f"Prediction error: {e}")
#         raise HTTPException(status_code=400, detail="Error processing transaction")

# # Transaction history retrieval endpoint
# @app.get("/history")
# async def get_history(user=Depends(get_current_user)):
#     transactions = await get_transactions_for_user(user.id)
#     return transactions

# # Additional routes can be added below as needed


import torch
import joblib
from fastapi import FastAPI, Depends, HTTPException, status, File, UploadFile, Body, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import logging
from app.firebase import verify_token
from app.database import connect_db, disconnect_db
from app.schemas import UserCreate, TransactionCreate
from app.crud import get_user_by_uid, create_user, create_transaction, get_transactions_for_user
from app.services import preprocess_transaction, predict_fraud
import io
import pandas as pd
from app.services import RegularizedHybridModel



app = FastAPI()


# Load ML model



# Initialize model with correct parameters
model = RegularizedHybridModel(feature_dim=15) # use correct feature_dim matching training
# Load weights
state_dict = torch.load('models/4th_model.pth', map_location=torch.device('cpu'))
model.load_state_dict(state_dict)
# Set model to eval mode
model.eval()



# Load scaler and encoder
scaler = joblib.load('models/scaler.joblib')
encoder = joblib.load('models/encoder.joblib')


# CORS Middleware for local testing - restrict in production!
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # <-- restrict this for production
    allow_credentials=True,
    allow_methods=["*"],
     allow_headers=["*"],
)


# Logging setup
logger = logging.getLogger("uvicorn.error")
logger.setLevel(logging.INFO)


@app.on_event("startup")
async def startup():
    await connect_db()


@app.on_event("shutdown")
async def shutdown():
    await disconnect_db()


# Dependency for Firebase Authentication
async def get_current_user(authorization: str = Header(None)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing or invalid authorization token")
    token = authorization.split(" ")[1]
    user_info = await verify_token(token)
    if not user_info:
        raise HTTPException(status_code=401, detail="Invalid Firebase token")
    user = await get_user_by_uid(user_info['uid'])
    if not user:
        user = await create_user(UserCreate(firebase_uid=user_info['uid'], email=user_info.get('email', '')))
    return user


# Auth route - get current user info
# @app.get("/auth/me")
# async def read_me(user=Depends(get_current_user)):
#     return {"user_id": user.id, "email": user.email}


# CSV upload & analyze
@app.post("/data/upload")
async def upload_csv(file: UploadFile = File(...)):
    contents = await file.read()
    try:
        df = pd.read_csv(io.BytesIO(contents))
        # Add more detailed data analysis if needed here
        return {"message": "CSV processed successfully", "row_count": len(df), "column_count": len(df.columns)}
    except Exception as e:
        logger.error(f"CSV processing error: {e}")
        raise HTTPException(status_code=400, detail="Invalid CSV file")


# Real-time fraud prediction endpoint
@app.post("/predict")
async def predict_transaction_route(body: dict = Body(...)):
    try:
        # Preprocess and predict using loaded model and scaler/encoder
        tensor_input = preprocess_transaction(body)
        prob, pred = predict_fraud(tensor_input)


        # Save transaction data and prediction result
        txn_record = TransactionCreate(
            transaction_amount=body['transaction_amount'],
            kyc_verified=body['kyc_verified'],
            account_age_days=body['account_age_days'],
            channel=body['channel'],
            timestamp=pd.to_datetime(body['timestamp']),
            fraud_probability=prob,
            is_fraud=bool(pred)
        )
        # Using a fixed test user id say 1 (replace with proper id if needed)
        await create_transaction(1, txn_record)


        return {"fraud_probability": prob, "is_fraud": bool(pred)}
    except Exception as e:
        logger.error(f"Prediction error: {e}")
        raise HTTPException(status_code=400, detail="Error processing transaction")


# Transaction history retrieval endpoint
@app.get("/history")
async def get_history():
    # Providing a constant test user id for now
    transactions = await get_transactions_for_user(1)
    return transactions


# Additional routes can be added below as needed
