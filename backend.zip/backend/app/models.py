from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
import datetime


Base = declarative_base()

class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True, index=True)
    firebase_uid = Column(String, unique=True, index=True)
    email = Column(String, unique=True, index=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class Transaction(Base):
    __tablename__ = 'transactions'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    transaction_amount = Column(Float)
    kyc_verified = Column(String)
    account_age_days = Column(Integer)
    channel = Column(String)
    timestamp = Column(DateTime)
    fraud_probability = Column(Float)
    is_fraud = Column(Boolean)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
