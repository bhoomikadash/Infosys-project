from pydantic import BaseModel, EmailStr
from typing import Optional
import datetime


class UserBase(BaseModel):
    email: EmailStr


class UserCreate(UserBase):
    firebase_uid: str


class User(UserBase):
    id: int

    class Config:
        from_attributes = True


class TransactionBase(BaseModel):
    transaction_amount: float
    kyc_verified: str
    account_age_days: int
    channel: str
    timestamp: datetime.datetime


class TransactionCreate(TransactionBase):
    fraud_probability: float
    is_fraud: bool


class Transaction(TransactionBase):
    id: int
    user_id: int
    fraud_probability: float
    is_fraud: bool
    created_at: datetime.datetime

    class Config:
        from_attributes = True
