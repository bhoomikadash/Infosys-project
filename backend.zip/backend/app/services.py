import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import joblib
import datetime

# Define your model architecture matching the training code
class RegularizedHybridModel(nn.Module):
    def __init__(self, feature_dim, lstm_hidden_dim=64, lstm_layers=1,
                 transformer_layers=2, nhead=4, transformer_dim=128, output_dim=1, dropout=0.3):
        super(RegularizedHybridModel, self).__init__()

        self.lstm = nn.LSTM(input_size=feature_dim,
                            hidden_size=lstm_hidden_dim,
                            num_layers=lstm_layers,
                            batch_first=True,
                            dropout=dropout if lstm_layers > 1 else 0)

        self.positional_encoding = nn.Parameter(torch.zeros(1, 500, lstm_hidden_dim))

        encoder_layer = nn.TransformerEncoderLayer(d_model=lstm_hidden_dim,
                                                   nhead=nhead,
                                                   dim_feedforward=transformer_dim,
                                                   dropout=dropout,
                                                   batch_first=True)
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=transformer_layers)

        self.output_layer = nn.Sequential(
            nn.Dropout(dropout),
            nn.Linear(lstm_hidden_dim, output_dim)
        )

    def forward(self, x):
        lstm_out, _ = self.lstm(x)
        seq_len = lstm_out.size(1)
        pos_enc = self.positional_encoding[:, :seq_len, :]
        x_transformed = lstm_out + pos_enc
        transformer_out = self.transformer_encoder(x_transformed)
        pooled = transformer_out.mean(dim=1)
        out = self.output_layer(pooled)
        return out

# Load scaler and encoder saved during training
scaler = joblib.load('models/scaler.joblib')
encoder = joblib.load('models/encoder.joblib')

# Initialize model and load trained weights
feature_dim = 15  # Update if your feature dimension changes
model = RegularizedHybridModel(feature_dim=feature_dim)
model.load_state_dict(torch.load('models/4th_model.pth', map_location=torch.device('cpu')))
model.eval()

def preprocess_transaction(data: dict):
    # Convert timestamp to datetime and extract time features
    timestamp = datetime.datetime.fromisoformat(data['timestamp'])

    numeric_features = [
        data['account_age_days'],
        data['transaction_amount'],
        timestamp.hour,
        timestamp.weekday(),
        timestamp.month,
        0,  # Placeholder features (update as needed)
        0,
        0,
        0,
    ]
    numeric_array = np.array([numeric_features], dtype=float)
    scaled_numeric = scaler.transform(numeric_array)

    # Encode categorical features using the loaded encoder
    cat_df = pd.DataFrame([[data['kyc_verified'], data['channel']]], columns=['kyc_verified', 'channel'])
    encoded_cat = encoder.transform(cat_df)

    # Concatenate scaled numeric and encoded categorical features
    final_input = np.hstack([scaled_numeric, encoded_cat])

    # Convert to torch tensor
    input_tensor = torch.tensor(final_input, dtype=torch.float32)

    # Add sequence length dimension (1)
    input_tensor = input_tensor.unsqueeze(1)

    return input_tensor

def predict_fraud(tensor_input):
    with torch.no_grad():
        logits = model(tensor_input).squeeze()
        prob = torch.sigmoid(logits).item()
        pred = int(prob > 0.5)
    return prob, pred
