import firebase_admin
from firebase_admin import credentials, auth
from app.config import settings

cred = credentials.Certificate(r"D:\Infosys\backend\firebase_service_account.json")  # Download this from Firebase console
firebase_admin.initialize_app(cred)

# Helper to verify Firebase token
async def verify_token(token: str):
    try:
        decoded = auth.verify_id_token(token)
        return decoded  # return user info
    except Exception as e:
        return None
